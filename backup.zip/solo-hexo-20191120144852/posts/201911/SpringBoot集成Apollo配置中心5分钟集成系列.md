title: SpringBoot集成Apollo配置中心（5分钟集成系列）
date: '2019-11-19 21:23:42'
updated: '2019-11-19 21:52:03'
tags: [apollo, 配置中心]
permalink: /articles/2019/11/19/1574169822114.html
---
![](https://img.hacpai.com/bing/20181007.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 相关文章
[基于Docker 5分钟搭建携程Apollo分布式配置中心](https://blog.lupf.cn/articles/2019/11/16/1573908705297.html)

### SpringBoot集成
- 第一步
  登录Apollo添加测试项目（apollo-test）
	![file](http://i.lupf.cn/FpluAwUTuudRID7m8auZQmuT-Puc)
- 第二步
  添加测试配置
  ```
  // 服务的端口
  server.port = 8888
  // 测试的key
  key = va
  a = 1
  ```
- 第三步
  添加依赖
  ```
  <dependency>
       <groupId>com.ctrip.framework.apollo</groupId>
       <artifactId>apollo-client</artifactId>
       <version>1.5.0</version>
  </dependency>
  ```
- 第四步，修改application.properties
  ```
  apollo.bootstrap.enabled = true

  #apollo项目的appid
  app.id=apollo-test
  
  #环境meta server的地址
  #实际的使用中  这个配置不会配置到这里
  apollo.meta=http://127.0.0.1:8080
  ```
	![file](http://i.lupf.cn/FiOeRw3BAIA66q6cbbg3AveI8yHB)
	> 到此，一个最基础的使用配置就已经完成

### 自定义配置文件及动态刷新

#### 获取单个配置
   ```
   // 和普通的配置方式一样，直接通过@Value获取即可
   @Value("${key}")
   private String key;
   ```

#### 获取自定义配置对象ApolloConfig
如果是由多个配置项组成的一个配置集合，那我们可以针对起做一个单独的配置对象
- 创建配置文件对象
  ```
  // 默认值就是application，如果配置是配在application命名空间下，就可以不用写value值
  // 如果是自定义的命名空间，就需要加上对于的名称
  @EnableApolloConfig(value = "application")
  @Component
  // 获取配置文件
  @ConfigurationProperties
  // lombok的get set
  @Data
  public class ApolloConfig {
      private String key;
      private Integer a;
  }
  ```
- 创建测试接口
  ```
  @RestController
  public class TestController {
      @Value("${key}")
      private String key;
  
      @Autowired
      ApolloConfig apolloConfig;
  
      @GetMapping("key")
      public String getKey() {
          return key;
      }
  
      @GetMapping("va")
      public String getVa() {
           return apolloConfig.toString();
      }
  }
  ```
- 测试
  ![file](http://i.lupf.cn/FjfASBNrweY_EaUP7xueJJyyYhv_)
  ![file](http://i.lupf.cn/Fny29p4bkGzVQ8WpKYPxS1zVzv9q)

#### 自动刷新
##### 第一种方式(推荐)
- 导入SpringCloud
  ```
  <dependency>
       <groupId>org.springframework.cloud</groupId>
       <artifactId>spring-cloud-starter</artifactId>
       <version>2.1.3.RELEASE</version>
  </dependency>
  ```
- 创建配置文件刷新帮助类ApolloRefreshConfig
  ```
  @Component
  @Slf4j
  public class ApolloRefreshConfig implements ApplicationContextAware {
  
      ApplicationContext applicationContext;
  
      @Autowired
      RefreshScope refreshScope;
  
      // 这里指定Apollo的namespace，非常重要，如果不指定，默认只使用application
      // 有多少命名空间(namespace)就指定多少个，这里传入的是一个数组
      @ApolloConfigChangeListener(value = {ConfigConsts.NAMESPACE_APPLICATION, "namespace1", "namespace2"})
      public void onChange(ConfigChangeEvent changeEvent) {
          for (String changedKey : changeEvent.changedKeys()) {
              log.info("apollo changed namespace:{} Key:{} value:{}", changeEvent.getNamespace(), changedKey, changeEvent.getChange(changedKey));
          }
          refreshProperties(changeEvent);
      }
  
      public void refreshProperties(ConfigChangeEvent changeEvent) {
          this.applicationContext.publishEvent(new EnvironmentChangeEvent(changeEvent.changedKeys()));
          refreshScope.refreshAll();
      }

      @Override
      public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
          this.applicationContext = applicationContext;
      }
  }
  ```
- 启用自动配置向
  ```
  spring.boot.enableautoconfiguration=true
  ```
- 重启测试
  ![file](http://i.lupf.cn/FlJusCvQTt5tfNkg2hdbGifp0Lr7)
  ![file](http://i.lupf.cn/FvcSfit7vJ01iV7VEX8SyK-sTdYg)
> 启动之后在apollo管理平台修改a的值，发布之后可以看到控制台会出现一天刷新记录，直接访问发现其值以及发生了变化

##### 第二种 @Value注解
  ```
  @Value("${key}")
  private String key;
  ```
缺点：该方式只有添加了@Value才能正常的刷新，如果配置比较多的话，无形中会增加很多体力劳动，第一种方式是一劳永逸的
	
#### meta server配置
一开始的测试中，我们会在application.properties中添加一个`apollo.meta=http://127.0.0.1:8080`，这个只是适合本地开发的时候使用一下，如果需要发布测试环境、正式环境的时候，如何如配置环境的地址来实现切换呢？官方提供了几种方式
- 第一种，setting配置文件
  ```
  // window在C:\opt\settings
  // linux或者mac在 /opt/settings
  // 下添加server.properties  并加入以下配置
  #集群环境
  #apollo.cluster=xxx
  #meta server地址
  apollo.meta=http://127.0.0.1:8080
  ```
- 第二种，运行时参数
  ```
  java -Dapollo.meta=http://127.0.0.1:8080 -jar xxx.jar
  ```
- 第三种，代码中设置
  ```
  System.setProperty("apollo.meta", "http://127.0.0.1:8080");
  ```
> 具体的meta server的地址请根据个人的实际情况填写

到此，Apollo的整合就已经完成，基于目前的情况几乎可以满足日常开发过程中的大部分需要了
	


