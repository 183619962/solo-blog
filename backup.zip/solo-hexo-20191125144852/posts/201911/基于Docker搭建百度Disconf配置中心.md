title: 基于Docker搭建百度Disconf配置中心
date: '2019-11-10 12:50:43'
updated: '2019-11-10 15:26:02'
tags: [disconf, docker, 配置中心]
permalink: /articles/2019/11/10/1573361443261.html
---
![](https://img.hacpai.com/bing/20181024.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


#### Disconf涉及到的所有资源
- Mysql 
- Redis 
- Nginx
- Tomcat
- Zookeeper (3.3.6,源码使用的这个版本的库，这里也就使用对应版本的软件)
- 辅助
	- JDK 
	  > 有人说1.8无法编译,亲测1.7和1.8都是可以正常编译的,如果你在编译的过程中遇到问题可以试着更换一下JDK的版本再试试
	- Maven

#### Disconf官方仓库
[https://github.com/knightliao/disconf.git](https://github.com/knightliao/disconf.git)
通过git或直接下载的方式,将源码下载下来
- 下载后的源码
![file](http://i.lupf.cn/FlRP61jEibb92u4EzKUyoX49XZ1l)

#### 涉及的Docker镜像及说明
- 基础流程
	![file](http://i.lupf.cn/FiMR1M4PfyoGuseOBtEm4mluzDHW)
- 说明
	- 灰色部分
	  > 使用Docker官方基础镜像即可
	- 绿色部分
	  > 使用我个人创建的公共镜像即可
	- 黄色部分 
	  >为了方便后续的使用，这里最好是个性化的定制并创建一下
- 导读
  > 在刚刚开始搭建的时候，由于设计到太多的东西，会让人觉得特别的麻烦，所以得先根据上面的图，知道各个模块之间的关系，只要理清楚之后，整个环境的搭建就会思路很清晰

#### 个性化Disconf项目
如果只是单纯想大家一个Disconf配置中心的服务，其实这一步也是可以不需要进行个性化的，但是我们搭建配置中心的目的就是真实的使用（比如整合至SpringBoot），如果这里不做一些个性化的调整，后续使用的过程中会遇到一些问题；因此，在环境搭建的这一步就将个性化的东西调整好，避免使用过程中出现问题再回来调整服务；
- 第一步；任意位置创建配置文件目录
  ```
  mkdir /usr/local/docker/disconf/online-resources
  ```
- 第二步，将配置文件拷贝至上面创建的目录
  ```
  # 进入源码的web项目目录
  cd disconf/disconf-web
  # 进入配置文件目录
  cd profile/rd
  # 拷贝数据库配置
  cp jdbc-mysql.properties /usr/local/docker/disconf/online-resources/
  # 拷贝redis配置
  cp redis-config.properties /usr/local/docker/disconf/online-resources/
  # 拷贝ZK配置
  cp zoo.properties jdbc-mysql.properties /usr/local/docker/disconf/online-resources/
  # 拷贝application配置
  # 注意这里一定要将application-demo.properties改名为application.properties
  cp application-demo.properties jdbc-mysql.properties /usr/local/docker/disconf/online-resources/application.properties
  ```
- 第三步；修改数据库配置
  ```
  vim jdbc-mysql.properties
  ```
  ```
  # 其他都可以都可以不动 只要是修改以下这几行配置
  # mysqlhost:3306 如果是使用Docker重新安装，mysqlhost就是数据库容器的名称
  # 如果你想使用已有的数据库，那么这里就使用你当前数据库的地址及密码，记得在已有的Mysql创建disconf库并执行下面的数据库脚本
  #           disconf/disconf-web/sql/0-init_table.sql
  #           disconf/disconf-web/sql/1-init_data.sql
  #           disconf/disconf-web/sql/201512/20151225.sql
  #           disconf/disconf-web/sql/20160701/20160701.sql
  jdbc.db_0.url=jdbc:mysql://mysqlhost:3306/disconf?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&rewriteBatchedStatements=false
  jdbc.db_0.username=root
  jdbc.db_0.password=123456
  ```
- 第四步；修改redis配置
  ```
  vim redis-config.properties
  ```
  ```
  # 默认是使用的2个redis；可以只配置一个，记住！记住！记住！第二个redis的配置不要删除
  redis.group1.retry.times=2
  #
  redis.group1.client1.name=BeidouRedis1
  # host地址如果使用Docker新安装的话redis_host_1为redis容器的别名
  # 如果使用已有的redis服务，这里就填已有redis的地址，如：192.168.1.100
  redis.group1.client1.host=redis_host_1
  redis.group1.client1.port=6379
  redis.group1.client1.timeout=5000
  # 有密码的话这里就填密码 没有密码的话就把这行配置注释掉
  #redis.group1.client1.password=foobared
  #
  # 第二个redis的配置可以不需要 但是下面的配置必须在，不能删除
  redis.group1.client2.name=BeidouRedis2
  redis.group1.client2.host=127.0.0.1
  redis.group1.client2.port=6380
  redis.group1.client2.timeout=5000
  redis.group1.client2.password=foobared
  #
  redis.evictor.delayCheckSeconds=300
  redis.evictor.checkPeriodSeconds=30
  redis.evictor.failedTimesToBeTickOut=6
  ```
- 第五步；修改zk的配置**（重要）**
  ```
  vim zoo.properties
  ```
  ```
  #hosts=127.0.0.1:8581,127.0.0.1:8582,127.0.0.1:8583
  # 这里可以填写已经存在的zk服务，单服务或者集群都是可以的
  # 如果没有zk的服务，就填docker宿主机的ip加zk映射的宿主机映射的端
  # 如会将zk安装在192.168.1.100的机器上，同时将容器的2181端口映射到12181端口，就填写以下地址
  hosts=192.168.1.100:12181
  #
  # zookeeper的前缀路径名
  zookeeper_url_prefix=/disconf
  ```
- 第六步；修改application配置
  ```
  # 以下是当配置修改之后的邮件通知，可以不用修改，并不会影响使用
  # 如果需要通知话可以按下面的要求修改为个性化的配置
  #
  # 服务器的domain
  #
  domain=disconf.com
  #
  # 邮箱设置
  #
  EMAIL_MONITOR_ON = true
  EMAIL_HOST = smtp.163.com
  EMAIL_HOST_PASSWORD = password
  EMAIL_HOST_USER = sender@163.com
  EMAIL_PORT = 25
  DEFAULT_FROM_EMAIL = disconf@163.com
  #
  # 定时校验中心的配置与所有客户端配置的一致性
  #
  CHECK_CONSISTENCY_ON= true
  #
  ```
- 第七步；设置环境变量
  ```
  # 第一步的时候创建用于存放配置文件的路径
  ONLINE_CONFIG_PATH=/usr/local/docker/disconf/online-resources
  # 编译成功之后用于保存war及其他编译之后资源信息的路径
  WAR_ROOT_PATH=/usr/local/docker/disconf/war
  export ONLINE_CONFIG_PATH
  export WAR_ROOT_PATH
  ```
- 第八步；编译
  ```
  # 进入源码的disconf-web目录
  cd disconf/disconf-web
  # 执行编译指令
  sh deploy/deploy.sh
  # 成功之后会保存在上面配置的war目录下
  ```
  ![file](http://i.lupf.cn/FikhbMTPvyMmY52KaNgDLFIW3ZJI)
- 第九步；创建server.xml
  ```
  # 进入编译之后的war目录
  cd /usr/local/docker/disconf/war
  vim server.xml
  ```
  ```
  <?xml version='1.0' encoding='utf-8'?>
    <Server port="8005" shutdown="SHUTDOWN">
    <Listener className="org.apache.catalina.startup.VersionLoggerListener" />
    <Listener className="org.apache.catalina.core.AprLifecycleListener" SSLEngine="on" />
    <Listener className="org.apache.catalina.core.JasperListener" />
    <Listener className="org.apache.catalina.core.JreMemoryLeakPreventionListener" />
    <Listener className="org.apache.catalina.mbeans.GlobalResourcesLifecycleListener" />
    <Listener className="org.apache.catalina.core.ThreadLocalLeakPreventionListener" />
    <GlobalNamingResources>
      <Resource name="UserDatabase" auth="Container"
                type="org.apache.catalina.UserDatabase"
                description="User database that can be updated and saved"
                factory="org.apache.catalina.users.MemoryUserDatabaseFactory"
                pathname="conf/tomcat-users.xml" />
    </GlobalNamingResources>
    <Service name="Catalina">
      <Connector port="8080" protocol="HTTP/1.1"
                 connectionTimeout="20000"
                 redirectPort="8443" />
      <Connector port="8009" protocol="AJP/1.3" redirectPort="8443" />
      <Engine name="Catalina" defaultHost="localhost">
        <Realm className="org.apache.catalina.realm.LockOutRealm">
          <Realm className="org.apache.catalina.realm.UserDatabaseRealm"
                 resourceName="UserDatabase"/>
        </Realm>
        <Host name="localhost"  appBase="webapps"
              unpackWARs="true" autoDeploy="true">
          <Valve className="org.apache.catalina.valves.AccessLogValve" directory="logs"
                 prefix="localhost_access_log." suffix=".txt"
                 pattern="%h %l %u %t &quot;%r&quot; %s %b" />
          <Context path="" docBase="/usr/local/tomcat/webapps/disconf-web" debug="0" reloadable="true" crossContext="true"/>
        </Host>
      </Engine>
    </Service>
  </Server>
  ```
- 第十步；创建Dockerfile
  ```
  cd /usr/local/docker/disconf/war
  vim Dockerfile
  ```
  ```
  #基础镜像使用tomcat:7.0.77-jre8
  FROM tomcat:7.0.77-jre8
  #作者
  MAINTAINER lupf <397729842@qq.com>
  #定义工作目录
  ENV TOMCAT_BASE /usr/local/tomcat
  #复制配置文件
  COPY ./server.xml $TOMCAT_BASE/conf/
  #复制war包
  COPY ./disconf-web.war $TOMCAT_BASE/webapps/
  #给配置文件增加读权限
  RUN chmod a+xr $TOMCAT_BASE/conf/server.xml
  #删除默认的ROOT文件件
  RUN rm -rf $TOMCAT_BASE/webapps/ROOT
  ```
- 第十一步；创建Docker镜像
  ```
  docker build -it disconf-web:1.0.0 .
  ```
  ![file](http://i.lupf.cn/FvDtlaPsVrBuUmT1rbMltKDSDp0u)

### 运行Disconf
- 创建docker-compose.yml
  ```
  version: '2'
  services:
    # redis就使用官方的redis镜像即可
    # 如果使用已有的Redis，可以把这部分注释掉
    disconf_redis_1:
      image: redis:4.0.9
      restart: always
    # zookeeper使用官方的3.3.6版本的镜像
    # 如果使用已有的zk可以把这部分注释掉
    disconf_zookeeper: 
      image: zookeeper:3.3.6
      restart: always
      ports:
        #端口指定请和上面zoo.properties配置一一致
        - "12181:2181"
    disconf_mysql:
      image: pengfeilu/disconf-mysql:5.7.22.1
      environment:
        MYSQL_ROOT_PASSWORD: 123456
      # 如果不需要外部访问可以不映射端口
      ports:
        - "3309:3306"
      restart: always
    disconf_tomcat:
      # 这里的镜像使用上面刚刚编译好的镜像
      image: disconf-web:1.0.0
      # 如果web项目中使用的是docker的容器名称进行访问的话
      # 这里就需要对别名进行管理，请保持:后面的和各properties中的别名一致
      links:
        - disconf_redis_1:redis_host_1
        # 由于zk涉及到后续的一些自动刷新等操作，因此这里不建议使用别名，直接使用对应的ip即可，所以这里的配置直接注释掉
        #- disconf_zookeeper:zkhost
        - disconf_mysql:mysqlhost
      restart: always
    disconf_nginx:
      image: pengfeilu/disconf-nginx:1.0.0
      # 因为需要通过nginx访问disconf的服务，因此这里需要做一个别名关联
      links:
        - disconf_tomcat:tomcathost
      # 这里就是管理页面的端口，具体映射到宿主机的那个端口可以根据实际情况来定
      ports:
        - "8880:80"
      restart: always
  ```

- 运行
  ```
  docker-compose up -d
  ```
  ![file](http://i.lupf.cn/Fqs-p1gfg6o6udb3bYGxSEm6K91M)
- 进入管理页面
  > http://ip:8880  8880为上面nginx端口，如果有改变请自行更换，用户名:admin 密码:admin
  
	![file](http://i.lupf.cn/FiX4UIZNCkSJhjBxI6qQgQKsBGjC)


> 看到这里，且都创建成功之后，基础的功能性使用已经没有任何问题了，如果你不想了解几个公共镜像的创建过程，本文也就到此结束

------

#### mysql及nginx公共镜像的创建
上面的docker-compose文件中出现了`pengfeilu/disconf-mysql:5.7.22.1`和`pengfeilu/disconf-nginx:1.0.0`两个镜像，由于这两个镜像可以做成公共的基础镜像，因此在上面的基础环境搭建过程中就没有进行说明，下面针对这两个镜像进行一下详细的创建过程说明
##### pengfeilu/disconf-mysql:5.7.22.1
这个镜像的目的其实很简单，就是启动的时候自动将Disconf相关的数据库、表、数据自动创建好，避免Mysql启动之后还需要手动去创建
- 第一步，准备默认sql
  ```
  # 任意目录
  mkdir /usr/local/docker/disconf/mysql
  # 进入源码disconf-web
  cd disconf/disconf-web/sql
  # 将里面的sql全部拷贝至/usr/local/docker/disconf/mysql
  ```
  ![file](http://i.lupf.cn/FrxAiiG5LgWcZGoW-RNQY4Z8zsks)
- 第二步；创建自动执行sql的shell脚本
  ```
  vim init_db.sh
  ```
  ```
  #!/bin/bash
  mysql -uroot -p$MYSQL_ROOT_PASSWORD <<EOF
  source $WORK_PATH/0-init_table.sql;
  source $WORK_PATH/1-init_data.sql;
  source $WORK_PATH/20151225.sql; 
  source $WORK_PATH/20160701.sql;
  ```
- 第三步，创建Mysql的配置文件
  ```
  vim mysql.cnf
  ```
  ```
  [mysql]
  default-character-set = utf8
  [mysql.server]
  default-character-set = utf8
  [mysqld_safe]
  default-character-set = utf8
  [client]
  default-character-set = utf8
  [mysqld]
   character_set_server=utf8
  init_connect='SET NAMES utf8'
  sql_mode=STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION
  ```

- 第四步；创建Dockerfile
  ```
  vim Dockerfile
  ```
  ```
  # mysql 官方镜像
  FROM mysql:5.7.22
  # 作者
  MAINTAINER lupf <397729842@qq.com>
  # 定义会被容器自动执行的目录
  ENV AUTO_RUN_DIR /docker-entrypoint-initdb.d
  # 定义工作目录
  ENV WORK_PATH /usr/local/work
  # 将要执行的sql脚本拷贝至工作目录
  COPY ./*.sql $WORK_PATH/
  # 将执行sql的shell脚本拷贝至docker-entrypoint-initdb.d，这个目录会在容器启动的时候自动执行下面的指令
  COPY ./init_db.sh $AUTO_RUN_DIR/
  # 将配置文件拷贝到对应的目录
  COPY ./mysql.cnf /etc/mysql/mysql.conf.d/
  # 给执行文件增加可执行权限
  RUN chmod a+x $AUTO_RUN_DIR/*
  ```

- 第五步；构建镜像
  ```
  docker build -t disconf-mysql:5.7.22.1 .
  ```
  ![file](http://i.lupf.cn/FsqgVb2MEzY0r-YsDrKojVEo5rnf)

##### pengfeilu/disconf-nginx:1.0.0
nginx这部分的主要作用是`前端页面的代理`及`前后端交互的转发`，所以nginx的镜像也就主要包含了这两部分的配置
- 第一步；静态资源整理
  ```
  # 创建Nginx的打包工作目录
  mkdir /usr/local/docker/disconf/nginx
  # 进入到Disconf编译之后保存的目录
  cd /usr/local/docker/disconf/war
  # 找到html目录，将此目录拷贝到上面创建的打包工作目录
  cp -rf html /usr/local/docker/disconf/nginx
  ```
  ![file](http://i.lupf.cn/FqvBtmQXvFA7OzT0eXprulMmyyKL)
- 第二步；创建nginx的配置文件
  ```
  vim nginx.conf
  ```
  ```
  http {
      include       /etc/nginx/mime.types;
      default_type  application/octet-stream;
      log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';
      access_log  /var/log/nginx/access.log  main;
      sendfile        on;
      #tcp_nopush     on;
      keepalive_timeout  65;
      #gzip  on;
      #include /etc/nginx/conf.d/*.conf;
      #
     upstream disconf {
          # disconf服务的地址,为了通用这个nginx镜像,这里使用的别名的方式
          # tomcathost为disconf服务容器的名称,然后通过link的方式进行关联  
          server tomcathost:8080;  
      }  
      #
      server {  
          listen   80;  
          server_name localhost;  
          access_log logs/disconf_access.log;  
          error_log logs/disconf_error.log;  
          location / {  
              # 该目录下存放的是disconf的静态页面
              root /usr/local/work/html;  
              if ($query_string) {  
                  expires max;  
              }  
          }  
          # disconf api接口相关的代理转发
          location ~ ^/(api|export) {  
              proxy_pass_header Server;  
              proxy_set_header Host $http_host;  
              proxy_redirect off;  
              proxy_set_header X-Real-IP $remote_addr;  
              proxy_set_header X-Scheme $scheme;  
              proxy_pass http://disconf;  
          }  
      }  
  }
  ```

- 第三步；创建Dockerfile
  ```
  vim Dockerfile
  ```
  ```
  #基础镜像使用nginx:stable
  FROM nginx
  #作者
  MAINTAINER lupf <397729842@qq.com>
  #定义工作目录
  ENV WORK_PATH /usr/local/work/html
  #定义nginx配置文件所在目录
  ENV NGINX_CONF_DIR /etc/nginx
  #定义nginx配置文件名称
  ENV NGINX_CONF_FILE_NAME nginx.conf
  #创建工作文件夹
  RUN mkdir -p $WORK_PATH
  #创建nginx日志文件夹
  RUN mkdir -p /etc/nginx/logs/
  #复制nginx配置文件
  COPY ./$NGINX_CONF_FILE_NAME $NGINX_CONF_DIR/
  #复制网页的静态资源文件
  COPY ./html $WORK_PATH/
  #给配置文件增加读权限
  RUN chmod a+xr $NGINX_CONF_DIR/$NGINX_CONF_FILE_NAME
  ```
- 第四步；构建镜像
  ```
  docker build -t disconf-nginx:1.0.0 .
  ```

#### 总结
到此，使用Docker搭建的Disconf环境已经全部完成了，其实整个过程，最重要的也就是Disconf源码编译那块儿，其他的像Mysql、zk、redis都是一些辅助性的软件，只要安装运行起来，并将Disconf的配置文件配置并关联过去即可。



