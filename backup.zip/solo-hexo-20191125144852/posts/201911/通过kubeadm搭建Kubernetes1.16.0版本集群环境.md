title: 通过kubeadm搭建Kubernetes(1.16.0版本)集群环境
date: '2019-11-23 20:42:17'
updated: '2019-11-23 20:46:28'
tags: [kubernetes, docker, kubeadm]
permalink: /articles/2019/11/23/1574512937074.html
---
![](http://i.lupf.cn/FlS5s6rjdWMP0oE1q8sT1vkBhuy6)

### 准备工作
- 防火墙配置
  - 关闭防火墙（测试环境）
    ```
    // 在内网网络环境安全的情况下，可以关闭防火墙 
    systemctl disable firewalld
    systemctl stop firewalld
    ```
  - 开放端口（生产）
    ```
    //防火墙对外开放以下端口
    //MASTER节点
    6443 Kubernetes API server 
    2379-2380 etcd server client API 
    10250 Kubelet API 
    10251 kube-scheduler 
    10252 kube-controller-manager 
    10255 Read-only Kubelet API (Heapster) 
    //Worker节点
    10250 Kubelet API 
    10255 Read-only Kubelet API (Heapster) 
    30000-32767 Default port range for NodePort Services. Typically, these ports would need to be exposed to external load-balancers, or other external consumers of the application itself.
    ```
- 主机禁用SELinux
  ```
  setenforce 0
  sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config
  ```
  ![file](http://i.lupf.cn/Fsb-MVu4fJipjqVMsUY4zljg97v9)
- 关闭Swap
  ```
  swapoff -a
  yes | cp /etc/fstab /etc/fstab_bak
  cat /etc/fstab_bak |grep -v swap > /etc/fstab
  //不关闭安装会出现以下错误
  ```
  ![file](http://i.lupf.cn/FhGkS_I-toXNzjlaGb_Th5m3Op-p)
- 配置内核参数
  ```
  echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
  echo "net.bridge.bridge-nf-call-ip6tables = 1" >> /etc/sysctl.conf
  echo "net.bridge.bridge-nf-call-iptables = 1" >> /etc/sysctl.conf
  # 执行命令以生效
  sysctl -p
  ```
  ![file](http://i.lupf.cn/FsU36WLhlSzgft9cUpUHeC0tqUhc)
- 配置Kubernetes国内yum源
  ```
  cat <<EOF > /etc/yum.repos.d/kubernetes.repo
  [kubernetes]
  name=Kubernetes
  baseurl=http://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64
  enabled=1
  gpgcheck=0
  repo_gpgcheck=0
  gpgkey=http://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg
         http://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
  EOF
  ```
  ![file](http://i.lupf.cn/FtjZubCwIAmTCe41JPqPsNvTMpCW)
	
### 安装
- Docker的安装
  [CentOS 7下安装Docker及基础操作](https://blog.lupf.cn/articles/2019/11/23/1574503815568.html)
	> 注意，**不要安装最新的版本**，安装最新的就是19.+的版本会存在不兼容的问题，请根据教程安装18.09的版本

- 安装kubelet、kubeadm、kubectl
  ```
  yum install -y kubelet-1.16.0 kubeadm-1.16.0 kubectl-1.16.0
  ```
  ![file](http://i.lupf.cn/FtpMHb3FL-jaFY3McZqzUqiUwNUZ)
	
- 修改docker Cgroup Driver为systemd
  ```
  sed -i "s#^ExecStart=/usr/bin/dockerd.*#ExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock --exec-opt native.cgroupdriver=systemd#g" /usr/lib/systemd/system/docker.service
  ```
  > 如果需要查询安装的时候，即执行了**kubeadm reset**之后再此安装，可能会出现**[kubelet-check] The HTTP call equal to 'curl -sSL http://localhost:10248/healthz' failed with error: Get http://localhost:10248/healthz: dial tcp [::1]:10248: connect: connection refused**的错误，需要将这里的cgroup dirver改回至cgroupfs；可参考:[https://cloud.tencent.com/developer/article/1454325](https://cloud.tencent.com/developer/article/1454325)
  ![file](http://i.lupf.cn/FqIBRUx147MyYQcWc_-OPW2t8n00)
- Docker访问hub.docker.com不稳定的设置
  ```
  // 如果访问稳定的话可以不设置
  curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://f1361db2.m.daocloud.io
  ```
- 重启Docker
  ```
  systemctl daemon-reload && systemctl restart docker
  ```
- 启动 kubelet
  ```
  systemctl enable kubelet && systemctl start kubelet
  ```

### 镜像制作
如果你扛的一手好梯子，可以忽略这一步；但是普遍情况下是无法访问到k8s.gcr.io进行镜像的下载；因此我们可以通过Docker的镜像转换为k8s的镜像；
- 第一步，在Docker官方仓库下载镜像
  ```
  docker pull mirrorgooglecontainers/kube-apiserver-amd64:v1.16.0
  docker pull mirrorgooglecontainers/kube-controller-manager-amd64:v1.16.0
  docker pull mirrorgooglecontainers/etcd-amd64:3.3.15-0
  docker pull mirrorgooglecontainers/kube-scheduler-amd64:v1.16.0
  docker pull mirrorgooglecontainers/kube-proxy-amd64:v1.16.0
  docker pull mirrorgooglecontainers/pause:3.1
  docker pull coredns/coredns:1.6.2
	```
- 对镜像重新打标签
  ```
  docker tag mirrorgooglecontainers/kube-apiserver-amd64:v1.16.0 k8s.gcr.io/kube-apiserver:v1.16.0
  docker tag mirrorgooglecontainers/kube-controller-manager-amd64:v1.16.0 k8s.gcr.io/kube-controller-manager:v1.16.0
  docker tag mirrorgooglecontainers/kube-scheduler-amd64:v1.16.0 k8s.gcr.io/kube-scheduler:v1.16.0
  docker tag mirrorgooglecontainers/kube-proxy-amd64:v1.16.0 k8s.gcr.io/kube-proxy:v1.16.0
  docker tag mirrorgooglecontainers/etcd-amd64:3.3.15-0 k8s.gcr.io/etcd:3.3.15-0
  docker tag mirrorgooglecontainers/pause:3.1 k8s.gcr.io/pause:3.1
  docker tag coredns/coredns:1.6.2 k8s.gcr.io/coredns:1.6.2
  ```
- 删除不用的镜像
  ```
  docker rmi mirrorgooglecontainers/kube-apiserver-amd64:v1.16.0 mirrorgooglecontainers/kube-controller-manager-amd64:v1.16.0 mirrorgooglecontainers/etcd-amd64:3.3.15-0  mirrorgooglecontainers/kube-scheduler-amd64:v1.16.0 mirrorgooglecontainers/kube-proxy-amd64:v1.16.0 mirrorgooglecontainers/pause:3.1 coredns/coredns:1.6.2
  ```
	
### 部署主节点
- 创建init-config.yaml
  - 第一种方式，通过kubeadm config
    ```
    // 这样就可以得到一个默认的初始化配置文件
    kubeadm config print init-defaults > init-config.yaml
		```
 - 第二种方式，手动创建（采用的方式）
    ```
    apiVersion: kubeadm.k8s.io/v1beta2
    kind: ClusterConfiguration
    controllerManager:
      ExtraArgs:
        horizontal-pod-autoscaler-use-rest-clients: "true"
        horizontal-pod-autoscaler-sync-period: "10s"
        node-monitor-grace-period: "10s"
    apiServer:
      ExtraArgs:
        runtime-config: "api/all=true"
        kubernetesVersion: "v1.16.0"
    ```
- 安装
  ```
  kubeadm init --config init-config.yaml
  ```
  ![file](http://i.lupf.cn/FsyRjw1M3KA4XP0_TOjVsjnAX6ZT)
  
	安装成功之后，docker ps可以看到以下运行的容器
  ![file](http://i.lupf.cn/Fr36kzpSsauC0UYR-cFjviKWUrV8)
- node加入集群的指令(**注意！！！ 以下的这部分很重要**)
  > 成功日志的最后一行为node节点加入的指令
  ```
  kubeadm join 192.168.1.22:6443 --token 91bfpw.smdtbfzc5ebsyldr \
    --discovery-token-ca-cert-hash sha256:a769a93dbec36b321195398380b590787cae98e9eb408d1fdb9e52af8c58d2dd
  ```
  - 查看token
    ```
    //在master节点执行以下指令 
    kubeadm token list
    ```
    ![file](http://i.lupf.cn/FpRJGhHZvkn2_eD1PZqfD5CMO9Se)
  - 创建一个新的token
    ```
    //创建一个临时token(24小时失效)
    kubeadm token create
    // 创建一个永久有效的token
    kubeadm token create --ttl 0 --print-join-command
    ```
    ![file](http://i.lupf.cn/FljXqm9rpaXqTSI48mS01i5E3BFL)
	
- 复制配置文件到普通用户的host目录
  ```
  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config
  ```
- 验证configmap
  ```
  kubectl get -n kube-system configmap
  ```
  ![file](http://i.lupf.cn/FnuBy6EoeRljR539iLrbHcztsALK)
- 安装网络插件
  ```
  kubectl apply -f "https://cloud.weave.works/k8s/net?k8s-version=$(kubectl version | base64 | tr -d '\n')"
	// 上面的指令执行成功之后需要等几分钟之后相关pod才能正常启动，下面是启动前后的截图
  kubectl get pods -n kube-system
  ```
  ![file](http://i.lupf.cn/Flx78p-K0zZjxhP8HGmVld9E7JqU)
  ![file](http://i.lupf.cn/FtXCsKQjc6lHQjCbBbuccrgbqjug)
	
### Node节点部署
- 准备工作
	> 从本文的开始到镜像制作的部分都在Node节点上执行一遍；也就是**准备工作部分**，**安装部分**及**镜像准备部分**都与主节点操作一致
- 加入主节点
  - 第一种方式，通过Master启动时的指令
    ```
    kubeadm join 192.168.1.22:6443 --token 91bfpw.smdtbfzc5ebsyldr \
    --discovery-token-ca-cert-hash sha256:a769a93dbec36b321195398380b590787cae98e9eb408d1fdb9e52af8c58d2dd
    ```
  - 第二种方式，通过yaml文件
    ```
    #vim join-config.yaml
    #添加以下配置
    #注意几个修改的地方，ip，oken （在主节点启动的时候都有打印出来）
    apiVersion: kubeadm.k8s.io/v1beta1
    kind: JoinConfiguration
    discovery:
      bootstrapToken:
        apiServerEndpoint: 192.168.1.22:6443
        token: 91bfpw.smdtbfzc5ebsyldr
        unsafeSkipCAVerification: true
      tlsBootstrapToken: 91bfpw.smdtbfzc5ebsyldr
    ```
    ```
    kubeadm join --config=json-config.yaml
    ```
    ![file](http://i.lupf.cn/FvfHEHD1_Ok2KABTKyPrad1-VL1W)

  - 更多节点同上操作即可

- 主节点查看节点情况
  ```
  kubectl get nodes
  // 出现下图说明集群环境已经正常
  ```
  ![file](http://i.lupf.cn/FuCVlkU2KBDS-MN5xk-eG80ZpD1Q)


### 重装Master
master安装可能因为一些配置的问题导致失败，但是由于master是由很多模块组成，因此可能装到一半，因为一些异常导致安装失败，再次安装的时候，可能会报端口被占用的情况；可以使用下面的指令重装
```
kubeadm reset
```
![file](http://i.lupf.cn/FujwFMx3COuo-pf2V_WFEWHi2yZa)

```
// 查询初始化安装
kubeadm init --config kubeadm.yaml
```
- 重装可能出现的错误
  ```
  [kubelet-check] The HTTP call equal to 'curl -sSL http://localhost:10248/healthz' failed with error: Get http://localhost:10248/healthz: dial tcp [::1]:10248: connect: connection refused.
  ```
  ![file](http://i.lupf.cn/FhKUSoKQamKR145E70liGD3gyfYK)
  > 前面安装master的时候也有提到，解决方案可参考可参考:[https://cloud.tencent.com/developer/article/1454325](https://cloud.tencent.com/developer/article/1454325)

### 其他错误
- python版本错误
  ```
  yum 安装的时候 出现以下错误
  ```
  ![file](http://i.lupf.cn/FjSEuk1Ryd8CnxTvEOtXYq3TVOzd)
  ```
  //vim /usr/bin/yum
  //将第一行的python版本
  #!/usr/bin/python
  //改为下面这一行
  #!/usr/bin/python2.7
	
  //vim /usr/libexec/urlgrabber-ext-down   修改同上
  ```
- Swap错误
  ```
  准备工作的时候有说道相关错误
  ```
  ![file](http://i.lupf.cn/Fsb-MVu4fJipjqVMsUY4zljg97v9)
	
	

-----

> 到此使用kubeadm搭建的kubernetes集群完成！！！
	



