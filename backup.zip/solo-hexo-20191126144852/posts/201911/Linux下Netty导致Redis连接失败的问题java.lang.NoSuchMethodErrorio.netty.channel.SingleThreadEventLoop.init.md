title: 'Linux下Netty导致Redis连接失败的问题java.lang.NoSuchMethodError: io.netty.channel.SingleThreadEventLoop.<init>'
date: '2019-11-21 14:53:39'
updated: '2019-11-21 14:53:39'
tags: [Netty, Redis]
permalink: /articles/2019/11/21/1574319219347.html
---
![](https://img.hacpai.com/bing/20171207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

- **背景**
  项目中同时使用了Redis和Netty，SpringBoot版本使用的2.1.6正式版；`在Linux环境下运行Redis无法正常连接`
	资源引用如下:
  ```
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-data-redis</artifactId>
  </dependency>
  ```
  ```
   <dependency>
      <groupId>io.netty</groupId>
      <artifactId>netty-all</artifactId>
      <version>4.1.38.Final</version>
  </dependency>
  ```
	错误信息如下:
  ![file](http://i.lupf.cn/FrevYHvORmezSriYTlKOZWtEz_Ww)
  ![file](http://i.lupf.cn/Fo6EbCBqD0aO7FLPn-DVcAaetLQ6)

- **冲突**
  由于spring-boot-starter-data-redis中也引用了Netty，且和我自行引用的版本不一致，如下图检查
  ![file](http://i.lupf.cn/FumrOb3pk9g75kRY72YHFD6IO82S)
  > 从上图可以看出，使用的是`4.1.36.Final`的版本，但是上面我自己引入了一个`4.1.38.Final`的版本，导致版本不一致

- **解决方式**
  将自己导入Netty的版本修改为上图中Redis关联的相同版本（4.1.36.Final）即可
  ```
  <dependency>
      <groupId>io.netty</groupId>
      <artifactId>netty-all</artifactId>
      <version>4.1.36.Final</version>
  </dependency>
  ```
	
- 总结
Netty作为一个优秀的框架，在很多三方库中都会作为基础库使用，如果版本不一致的话，就可能带来冲突问题，因此统一版本会减少或者规避很多问题

