title: CentOS 7下安装Docker及基础操作
date: '2019-11-23 18:10:15'
updated: '2019-11-23 18:10:15'
tags: [docker]
permalink: /articles/2019/11/23/1574503815568.html
---
![file](http://i.lupf.cn/FtKP6zjHVC38wg9pItu_Lzx7r2om)



#### Docker安装
- 第一步:
  移除旧的版本

  ```
  sudo yum remove docker \
                    docker-client \
                    docker-client-latest \
                    docker-common \
                    docker-latest \
                    docker-latest-logrotate \
                    docker-logrotate \
                    docker-selinux \
                    docker-engine-selinux \
                    docker-engine
  ```  
  移除历史镜像和容器等数据，如果之前已经安装了Docker，不移除，再次安装Docker，历史的镜像和容器都还存在，**注意！！！ 这行指令会删除历史的所有数据，请酌情执行**
  ```
  rm -rf /var/lib/docker
  ```

- 第二步
  安装一些必要的系统工具
  ```
  sudo yum install -y yum-utils device-mapper-persistent-data lvm2
  ```
- 第三步:
  添加软件源信息
  ```
  sudo yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
  ```
- 第四步:
  更新 yum 缓存
  ```
  sudo yum makecache fast
  ```
- 第五步:
  安装 最新的Docker-ce
  ```
  sudo yum -y install docker-ce
  ```
  安装指定版本
  ```
  sudo  yum install -y docker-ce-18.09.7 docker-ce-cli-18.09.7 containerd.io
  ```
- 第六步:
  启动 Docker 后台服务
  ```
  sudo systemctl start docker
  ```

----

#### Docker基础操作
##### Docker服务操作
- 启动docker

  ```
  sudo systemctl start docker
  ```
- 停止docker

  ```
  sudo systemctl stop docker
  ```
- 重启docker

  ```
  sudo systemctl restart docker
  ```
##### Docker镜像操作
- 查看镜像

  ```
  sudo docker images
  ```
- 拉取镜像
  docker pull 镜像名称:版本号  如:
  ```
  sudo docker pull redis:5.0.4
  ```
- 删除镜像

  ```
  sudo docker rmi 镜像ID
  ```

- 运行镜像

  ```
  sudo docker run --name test -p 80:80 -p 8081:8081 -v /data/log:/data/log --restart=always -d test:1.0.0
  ```
  - name
    表示运行的容器的别名
  - p
    宿主机的端口域容器端口的映射关系
  - v
    文件挂载
    - 时间同步
      ```
      -v /etc/localtime:/etc/localtime
      ```
  - restart
    重启方式，自动重启
  - d
    后台运行  

   
- 镜像打标签
  sudo docker tag 基础镜像:版本 镜像地址(默认docker仓库)/路径/镜像名称:版本 如:
  ```
  sudo docker tag redis:5.0.4 hub.c.163.com/test/redis:5.0.4
  ```
- 推送镜像

  ```
  sudo docker push hub.c.163.com/test/redis:5.0.4
  ```

##### Docker容器操作
- 查看容器运行情况

  ```
  sudo docker ps
  ```
- 查看所有的容器运行情况

  ```
  sudo docker ps -a
  ```
- 查询特定的容器

  ```
  sudo docker ps|grep redis
  ```
- 停止容器

  ```
  sudo docker stop 容器id
  ```
- 重启容器

  ```
  sudo docker restart 容器id
  ```
- 启动容器

  ```
  sudo docker start 容器id
  ```
- 删除容器

  ```
  sudo docker rm 容器id
  ```
- 查看容器运行的日志

  ```
  sudo docker logs -f 容器ID
  ```
  - Docker运行日志保存的目录
    ```
    cd /var/lib/docker/containers
    ```
  - 清理Docker容器运行的日志
    ```
    #首先进入上面的目录
    #cd进入对应的容器
    #清空  容器id-json.log的记录文件即可清理容器运行的日志
    #或者停止、删除、重启镜像
    ```
- 进入容器

  ```
  sudo docker exec -it 容器ID /bin/bash
  ```
  使用exit退出
- 执行容器内的脚本
  以Nginx检查配置文件是否正确测试
  ```
  sudo docker exec 容器ID /usr/sbin/nginx -s reload
  ```

##### Docker-compose安装
- pip安装docker-compose
  ~~~
  yum install epel-release
  yum install -y python-pip
  pip install docker-compose
  ~~~

- 基础命令
  ~~~
  #启动容器，如果镜像不存在则先下载镜像，如果容器没创建则创建容器，如果容器没启动则启动
  docker-compose up -d 
  #停止并移除容器
  docker-compose down 
  #重启服务
  docker-compose restart 
  ~~~
  

##### 容器日志管理
- 容器的日志查看
  ~~~
  sudo docker logs -f 容器ID
  ~~~
- 容器日志保存的位置
  ~~~
  /var/lib/docker/containers/
  ~~~
  以上路径下保存了当前容器的各种资源及配置，让容器被删除的时候，这里对应的文件夹也会被删除
  ![](https://img-blog.csdnimg.cn/2019082818483845.png)
  以下红色部分即为容器运行时的日志
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190828184922573.png)
- 带来的问题
  当容器不删除重启的时候，这里的**日志文件将会变得越来越大，占用了大量的内存资源**；而实际的情况下，以SpringBoot项目为例，我们都会在项目里面定义自己的日志策略，因此容器运行时记录的运行日志实际上是一份多余的日志；既然是日志，必定就会占用IO，IO又是一个比较耗时的操作，而且文件越大，操作的性能就会下降。既然没啥用，那我们何不关掉它。

###### 关闭容器运行日志
- 配置daemon.json
  ~~~
  vim /etc/docker/daemon.json
  
  #添加以下配置
  "log-driver":"none"
  ~~~
  ![](https://img-blog.csdnimg.cn/20190828185940838.png)
  ~~~
  #重启docker
  service docker restart
  ~~~
  移除并重新运行镜像，再来查看容器日志，发现*-json.log已经没有了
  个人的建议是，测试环境是可以开启这个容器日志，如果镜像测试一旦稳定，推到生产的时候，出于性能考虑(因为这部分日志没有太大的价值)，所以可以直接关闭掉；

###### 限制容器运行日志大小
- 配置daemon.json
  ~~~
  vim /etc/docker/daemon.json
  
  #添加以下配置
  "log-driver":"json-file",
  "log-opts": {"max-size":"1m", "max-file":"3"}
  
  ~~~
  - max-size
    表示日志文件的大小
  - max-file
    表示日志文件的个数，这里是3，那么最多会生成三个日志文件，每个日志文件最大1m；超过3个之后，会把最旧的那个文件给删除掉。
  ![](https://img-blog.csdnimg.cn/20190828190618222.png)
  ![](https://img-blog.csdnimg.cn/20190828193046553.png)

###### 定时任务清空日志
不太建议使用这种方式，虽然可以解决问题，但是我认为不是一个最好的方法
- 创建清除日志的脚本
  vim /etc/docker/clean_docker_container_logs.sh
  ~~~
  #!/bin/sh 
  
  echo "======== start clean docker containers logs ========"  
  #查找/var/lib/docker/containers/路径下以-json.log结尾的文件
  logs=$(find /var/lib/docker/containers/ -name *-json.log)  
  for log in $logs  
          do  
                  echo "clean logs : $log"  
                  #将对应文件的内容置为null
                  cat /dev/null > $log  
                  # 或者
                  # echo "">$log
          done  
  echo "======== end clean docker containers logs ========" 
  ~~~
  然后在crontab设置定时任务执行
  ~~~
  #5分钟执行一次
  */5 * * * * sh /etc/docker/clean_docker_container_logs.sh
  ~~~
  
  


